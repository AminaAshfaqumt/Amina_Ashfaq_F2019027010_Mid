import java.awt.FileDialog;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class Operation_File {
	GUI gui;
	String file_Name;
	String file_Address;
	
	public Operation_File(GUI gui) {
		this.gui=gui;	
	}
	public void newFile() {
		
		gui.textArea.setText("");
		gui.window.setTitle("New");
		file_Name=null;
		file_Address=null;
		
		
	}
	
	
	public void Open() {
		
		FileDialog fd= new FileDialog(gui.window,"Open",FileDialog.LOAD);
		fd.setVisible(true);
		if(fd.getFile()!=null) {
			file_Name=fd.getFile();
			file_Address=fd.getDirectory();
			gui.window.setTitle(file_Name);
		}
		
		System.out.println("File Addre and fileName"+file_Address + file_Name);
		
		try {
             BufferedReader br=new BufferedReader (new FileReader(file_Address + file_Name));
			
			gui.textArea.setText("");
			String line=null;
			while((line = br.readLine())!= null) {
				
				gui.textArea.append(line + "\n");
				
			}
			br.close();
			
			
		}catch(Exception e) {
			System.out.println("file not opened");
			
		}
		
		
	}
	
	public void Save() {
		
		if(file_Name == null) {
			SaveAs();
			
		}
		else {
			
			try {
	            FileWriter fr=new FileWriter (file_Address + file_Name);
				
				fr.write(gui.textArea.getText());
				gui.window.setTitle(file_Name);
			
				fr.close();
				
				
			}catch(Exception e) {
				System.out.println("Problem occured");
				
			}
			
			
			
		}
		
	}
	
	public void SaveAs() {
		
		FileDialog fd= new FileDialog(gui.window,"Save",FileDialog.SAVE);
		fd.setVisible(true);
		if(fd.getFile()!=null) {
			file_Name=fd.getFile();
			file_Address=fd.getDirectory();
			gui.window.setTitle(file_Name);
				
		}
		
		try {
            FileWriter fr=new FileWriter (file_Address + file_Name);
			
			fr.write(gui.textArea.getText());
		
			fr.close();
			
			
		}catch(Exception e) {
			System.out.println("Problem occured");
			
		}
		
		
		
	}
	
	public void Exit() {
		System.exit(0);
	}

}
